from pathlib import Path
import ast,importlib.util,json,hashlib
from decimal import Decimal
from typing import Any,Dict
from controllers.generic.modular_spot_core.recipe_contract import StrategyRecipe
from controllers.generic.modular_spot_core.recipe_compiler import bind_native_bundle,write_bundle
from controllers.generic.modular_spot import ModularSpotControllerConfig
out=Path('docs/controllers/modular_spot/evidence/2026-09-19-rust-candles/compatibility').resolve();out.mkdir(exist_ok=True)
recipe=StrategyRecipe(name='rust_candle_validation',family='rebound',symbols=('BTC-USDC',),account='isolated_data_only',quote_budget=Decimal('100'),max_positions=1,data_transport='stream',history=90,data_origin='http://127.0.0.1:8766',token_file='/run/secrets/modular_candle_reader')
bundle=bind_native_bundle(recipe);write_bundle(bundle,out/'native-export')
assert bundle['controllers'][0]['data']['transport']=='stream'
assert bundle['controllers'][0]['execution_enabled'] is False
helper=Path('/Users/s1kor/dev/trading/rsibot/.worktrees/rsibot-modular-handoff-validation/scripts/modular_recipe_handoff.py')
spec=importlib.util.spec_from_file_location('handoff',helper);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
packet=module.build_packet(out/'native-export',Path('controllers/generic').resolve(),idea_id='rust-candle-data-compatibility',title='Rust candle transport configuration compatibility',hypothesis='The native recipe can select the Rust stream without granting execution authority.',falsification='A changed transport or source passes the existing binding verification incorrectly.')
(out/'handoff.json').write_text(json.dumps(packet,indent=2)+'\n')
api=Path('/Users/s1kor/dev/trading/rsibot/.worktrees/hummingbot-api-modular-validation/routers/controllers.py');fn=next(n for n in ast.parse(api.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='_field_schema');ns={'Any':Any,'Dict':Dict,'Decimal':Decimal};exec(compile(ast.Module(body=[fn],type_ignores=[]),str(api),'exec'),ns)
fields={name:ns['_field_schema'](field) for name,field in ModularSpotControllerConfig.model_fields.items()}
payload={name:field['default'] for name,field in fields.items() if not field['required']};payload.update(id='modular_spot_rust_schema',connector_name='okx',trading_pair='BTC-USDC')
default=ModularSpotControllerConfig.model_validate(payload);assert default.data.transport=='snapshot'
payload.update(data=bundle['controllers'][0]['data'],max_records=90);stream=ModularSpotControllerConfig.model_validate(payload);assert stream.data.transport=='stream' and stream.execution_enabled is False
receipt={'native_source_sha256':bundle['source_sha256'],'recipe_sha256':bundle['recipe_sha256'],'native_config':'PASS stream90 disabled','api_schema_roundtrip':'PASS defaultsnapshot300 and explicitstream90; exactschemahelper,notdeployedAPI','api_helper_file_sha256':hashlib.sha256(api.read_bytes()).hexdigest(),'root_handoff':'PASS VERIFIED disabled unregistered','handoff_sha256':packet['packet_sha256'],'service_identity':'separately bound by smoke source.json; native source seal includes Python only'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
