import ast
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict
from controllers.generic.modular_spot import ModularSpotControllerConfig
source = Path('/Users/s1kor/dev/trading/rsibot/.worktrees/hummingbot-api-modular-validation/routers/controllers.py').read_text()
fn = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == '_field_schema')
ns = {'Any': Any, 'Dict': Dict, 'Decimal': Decimal}
exec(compile(ast.Module(body=[fn], type_ignores=[]), 'routers/controllers.py', 'exec'), ns)
fields = {name: ns['_field_schema'](field) for name, field in ModularSpotControllerConfig.model_fields.items()}
payload = {name: field['default'] for name, field in fields.items() if not field['required']}
payload.update(id='modular_spot_schema_probe', connector_name='okx', trading_pair='BTC-USDC')
config = ModularSpotControllerConfig.model_validate(payload)
assert config.execution_enabled is False
assert config.data.mode == 'native'
print('PASS: actual native ModularSpotControllerConfig template defaults roundtrip; execution_enabled=False')
