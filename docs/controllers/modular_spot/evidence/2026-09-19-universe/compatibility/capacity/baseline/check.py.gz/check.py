import asyncio, hashlib, json, os, resource, statistics, time
from collections import Counter
from pathlib import Path
import aiohttp
from aiohttp import web
from controllers.generic.modular_spot_core.candle_data import Dataset, SnapshotHub
from controllers.generic.modular_spot_core.candle_transport import CandleClient, create_app
from hummingbot.data_feed.candles_feed.candles_factory import CandlesFactory
from hummingbot.data_feed.candles_feed.data_types import CandlesConfig
from hummingbot.data_feed.candles_feed.okx_spot_candles.okx_spot_candles import OKXSpotCandles
OUT=Path('/private/tmp/pr55-publisher-capacity-20260919')
UNIVERSE=Path('/Users/s1kor/dev/trading/rsibot/.worktrees/hummingbot-modular-integration-pr57/docs/controllers/modular_spot/evidence/2026-09-19-universe/universe.json')
CAPTURES=[]
START=time.perf_counter(); WALL=time.time(); END=int(WALL//60)*60-60
CLOCK=lambda: WALL+time.perf_counter()-START

def stats(values):
    if not values:return {'count':0}
    rows=sorted(values)
    return {'count':len(rows),'min':rows[0],'p50':statistics.median(rows),'p95':rows[min(len(rows)-1,int(len(rows)*.95))],'max':rows[-1]}

def factory(spec):
    feed=CandlesFactory.get_candle(CandlesConfig(connector='okx',trading_pair=spec.trading_pair,interval='1m',max_records=90))
    assert type(feed) is OKXSpotCandles and feed.closed_candles_only
    feed.start=lambda:None
    feed.stop=lambda:None
    for n in range(90):feed._candles.append([float(END-(89-n)*60),100.,101.,99.,100.,5.,500.,0.,0.,0.])
    return feed

class MeasuredHub(SnapshotHub):
    def capture(self,**kw):
        begin=time.perf_counter()
        try:return super().capture(**kw)
        finally:CAPTURES.append(time.perf_counter()-begin)

class Reader(CandleClient):
    def __init__(self,*a,**kw):
        super().__init__(*a,**kw); self.cycles=[];self.codes=Counter();self.first_ready=None;self.failures=[]
    async def poll(self,*a,**kw):
        begin=time.perf_counter()
        try:
            result=await super().poll(*a,**kw)
            self.cycles.append(time.perf_counter()-begin);self.codes.update(result)
            if len(self.replica.snapshots)==294 and self.first_ready is None:self.first_ready=time.perf_counter()-START
            return result
        except Exception as exc:
            self.failures.append(type(exc).__name__+': '+str(exc));raise

async def main():
    cpu=time.process_time();rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    pairs=json.loads(UNIVERSE.read_bytes())['pairs'];assert len(pairs)==294
    specs=tuple(Dataset(connector='okx',trading_pair=p,interval='1m',history=90) for p in pairs)
    hub=MeasuredHub(specs,factory=factory,epoch='local-capacity-294')
    token='local-disposable-fixture-token-0123456789';tokenfile=OUT/'token';tokenfile.write_text(token);tokenfile.chmod(0o600)
    app=create_app(hub,token=token,clock=CLOCK,poll_seconds=1.)
    runner=web.AppRunner(app);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start()
    port=site._server.sockets[0].getsockname()[1]
    readers=[Reader(f'http://127.0.0.1:{port}',str(tokenfile),specs,clock=CLOCK,poll_seconds=1.) for _ in range(2)]
    lag=[]
    async def monitor():
        while True:
            begin=time.perf_counter();await asyncio.sleep(.02);lag.append(max(0.,time.perf_counter()-begin-.02))
    monitor_task=asyncio.create_task(monitor())
    for reader in readers:reader.start()
    try:
        await asyncio.sleep(25)
        report={'fixture_only':True,'public_connections':False,'native_feed_type':'OKXSpotCandles','datasets':294,'history':90,'readers':2,'universe_sha256':hashlib.sha256(UNIVERSE.read_bytes()).hexdigest(),'elapsed_seconds':time.perf_counter()-START,'capture_seconds':stats(CAPTURES),'event_loop_lag_seconds':stats(lag),'cpu_seconds':time.process_time()-cpu,'max_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'max_rss_delta_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss-rss,'hub_errors':hub.errors,'reader_results':[{'first_all_ready_seconds':r.first_ready,'full_poll_cycle_seconds':stats(r.cycles),'http_status_counts':dict(r.codes),'ready_datasets':len(r.replica.snapshots),'current_error':r.error,'dataset_errors':r.dataset_errors,'exceptions':r.failures} for r in readers]}
        (OUT/'evidence.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
    finally:
        for r in readers:await r.close()
        monitor_task.cancel();await asyncio.gather(monitor_task,return_exceptions=True);await runner.cleanup();tokenfile.unlink()

asyncio.run(main())
